import React, { Component } from 'react';
import { connect } from "react-redux";
import Restaurants from "./components/Restaurants";
import Filters from "./components/Filters";
import { loadAllRestaurants, loadRestaurants, loadFoods } from "./redux/actions";
import { RESTAURANTS, FOODS } from "./redux/constants";
import './App.css';

class App extends Component {

    constructor(props) {
        super(props);
        props.loadRestaurants(RESTAURANTS);
        props.loadAllRestaurants(RESTAURANTS);
        props.loadFoods(FOODS);
        console.log();
    }

    render() {
        return (
            <>
            <Filters/>
            <Restaurants />
            </>
        );
    }
}

export default connect(null, { loadAllRestaurants, loadRestaurants, loadFoods })(App);
