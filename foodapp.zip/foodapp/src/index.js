import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from "react-redux";
import ErrorBoundary from "./components/ErrorBoundary";
import store from "./redux/store";
import App from './App';
import './index.css';

const rootElement = document.getElementById("root");
ReactDOM.render(
    <ErrorBoundary>
        <Provider store={store}>
            <App />
        </Provider>
    </ErrorBoundary>
  ,
  rootElement
);
