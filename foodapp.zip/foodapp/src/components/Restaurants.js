import React from "react";
import { connect } from "react-redux";
import { getRestaurants, getRestaurantsByName, getRestaurantsByRating, getRestaurantsByNameAndRating } from "../redux/selectors";
import Restaurant from "./Restaurant";

const Restaurants = ({ restaurants }) => (
  <div className="Restaurants">
    {restaurants && restaurants.length
      ? restaurants.map((restaurant) => {
          return <Restaurant data={restaurant} key={restaurant.restaurantId}/>;
        })
      : "No Restaurants Found!"}
  </div>
);

const mapStateToProps = state => {
    console.log(state);
    let name = state.restaurants.restaurantName;
    let rating = state.restaurants.restaurantRating;
    if(name === "" && rating === "0")
        return { restaurants: getRestaurants(state).originalRestaurants };
    else if(name !== "" && rating === "0")
        return { restaurants: getRestaurantsByName(state, name) };
    else if(name === "" && rating !== "0")
        return { restaurants: getRestaurantsByRating(state, rating) };
    else if(name !== "" && rating !== "0")
        return { restaurants: getRestaurantsByNameAndRating(state, name, rating) };
    else
        return { restaurants: state.restaurants.restaurants };
};

export default connect(mapStateToProps, null)(Restaurants);
