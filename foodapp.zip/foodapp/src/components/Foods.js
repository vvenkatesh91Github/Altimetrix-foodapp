import React from "react";
import { connect } from "react-redux";
import Food from "./Food";
import { getFoodForRestaurants } from "../redux/selectors";

const Foods = ({ foods }) => (
  <div className="Foods">
    {foods && foods.length
      ? foods.map((food) => {
          return <Food data={food} key={food.foodId}/>;
        })
      : "No Food Found!"}
  </div>
);

const mapStateToProps = state => {
    const foods = getFoodForRestaurants(state);
    console.log(foods);
    return {foods};
};

export default connect(mapStateToProps, null)(Foods);
