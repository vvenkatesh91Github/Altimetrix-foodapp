import React from "react";
import { connect } from "react-redux";
import { searchRestaurant } from "./../redux/actions";

class Filters extends React.Component {

    searchRestaurant() {
        this.props.searchRestaurant(document.getElementById("restaurantName").value, document.getElementById("restaurantRating").value);
    }

    render() {
        return (
            <div className="filters">
                <input type="text" placeholder="Restaurant" id="restaurantName"/>
                <select id="restaurantRating">
                    <option value="0">Rating Above</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                </select>
                <button onClick={() => this.searchRestaurant()}>Find</button>
            </div>
        );
    }
}


export default connect(null, { searchRestaurant })(Filters);
