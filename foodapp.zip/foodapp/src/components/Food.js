import React from "react";

const Restaurant = (props) => (
<div className="card food">
    <img className="card-img-top" src={props.data.thumbnail} alt="Food"/>
    <div className="card-body">
        <h5 className="card-title">{props.data.name}</h5>
        <p className="card-text">{props.data.description}</p>
    </div>
</div>
);


export default Restaurant;
