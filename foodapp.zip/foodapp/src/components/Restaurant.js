import React from "react";
import ReactDOM from 'react-dom';
import { Provider , connect } from "react-redux";
import Foods from "./Foods";
import store from "./../redux/store";
import { selectResturant } from "./../redux/actions";

class Restaurant extends React.Component {

    selectResturant(restaurantId) {
        const rootElement = document.getElementById("root");
        ReactDOM.render(<Provider store={store}><Foods/></Provider>,
          rootElement
        );
        this.props.selectResturant(restaurantId);
    }

    render() {
        return (
            <div className="card restaurant" onClick={() => this.selectResturant(this.props.data.restaurantId)}>
                <img className="card-img-top" src={this.props.data.thumbnail} alt="Food"/>
                <div className="card-body">
                    <h5 className="card-title">{this.props.data.name}</h5>
                    <p className="card-text">{this.props.data.description}</p>
                </div>
            </div>
        );
    }
}


export default connect(null, { selectResturant })(Restaurant);
