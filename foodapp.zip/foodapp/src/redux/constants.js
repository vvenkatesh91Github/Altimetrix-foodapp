export const initialState = {
    restaurants: [],
    foods : [],
    cart: []
  };

export const RESTAURANTS = [
	{
		restaurantId: 1,
		name: "ABC",
		description: "Biryani, Chettinad",
		rating: 2,
		type: "nonveg",
		approxDeliveryTime: 90,
		bestDeal: "200 for two",
		thumbnail: "food.jfif"
	},
	{
		restaurantId: 2,
		name: "DEF",
		description: "Idly, Dosa",
		rating: 4.3,
		type: "veg",
		approxDeliveryTime: 15,
		bestDeal: "150 for two",
		thumbnail: "food.jfif"
	}
]

export const FOODS = [
	{
		foodId: 1,
		name: "Chicken Biryani",
		description: "Biryani",
		isRecommended: true,
		price: 100,
		isVeg: false,
		quantity: 0,
		inRestaurants: [1, 2],
		thumbnail: "food.jfif"
	},
	{
		foodId: 2,
		name: "Mutton Biryani",
		description: "Biryani",
		isRecommended: true,
		price: 150,
		isVeg: false,
		quantity: 0,
		inRestaurants: [1],
		thumbnail: "food.jfif"
	}
]