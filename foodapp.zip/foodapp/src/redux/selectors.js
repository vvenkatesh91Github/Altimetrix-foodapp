export const getRestaurants = store => store.restaurants;

export const getAllRestaurants = store => store.restaurants.originalRestaurants;

export const getFoods = store => store.foods;

export const getRestaurantsByName = (store, nameLike) => {
    const restaurants = getAllRestaurants(store);
    if(nameLike !== "")
        return restaurants.filter(restaurant => restaurant.name.toLowerCase().indexOf(nameLike.toLowerCase()) >= 0);
    return restaurants;
}

export const getRestaurantsByRating = (store, rating) => {
    const restaurants = getAllRestaurants(store);
    if(rating !== 0)
        return restaurants.filter(restaurant => restaurant.rating >= rating);
    return restaurants;
}

export const getRestaurantsByNameAndRating = (store, nameLike, rating) => {
    const restaurants = getAllRestaurants(store);
    if(nameLike !== "")
        return restaurants.filter(restaurant => ( restaurant.name.toLowerCase().indexOf(nameLike.toLowerCase()) >= 0 && restaurant.rating >= rating ));
    return restaurants;
}

export const getFoodForRestaurants = (store) => {
    const foods = getFoods(store);
    if(store.restaurants.restaurantId !== "0")
        return foods.filter(food => food.inRestaurants.indexOf(store.restaurants.restaurantId) >= 0);
    return foods;
}