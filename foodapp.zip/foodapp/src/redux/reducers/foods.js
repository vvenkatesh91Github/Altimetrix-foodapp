import { LOAD_FOOD } from "../actionTypes";

const initialFoods = {
    foods : []
}

const foodsReducer = (state = initialFoods, action) => {
    switch (action.type) {
        case LOAD_FOOD: {
            const foods = action.foods;
            return foods;
        }
        default:
            return state;
    }
}

export default foodsReducer;