import { LOAD_ALL_RESTAURANTS, LOAD_RESTAURANTS, SELECT_RESTAURANT, SEARCH_RESTAURANT } from "../actionTypes";

const initialRestaurants = {
    restaurants : [],
    originalRestaurants: [],
    restaurantName : "",
    restaurantRating : 0,
    restaurantId: 0
}

const restaurantsReducer = (state = initialRestaurants, action) => {
    switch (action.type) {
        case LOAD_ALL_RESTAURANTS: {
            return {
                ...state,
                originalRestaurants: action.restaurants
            };
        }
        case LOAD_RESTAURANTS: {
            return {
                ...state,
                restaurants: action.restaurants
            };
        }
        case SEARCH_RESTAURANT: {
            return {
                ...state,
                restaurantName: action.restaurantName,
                restaurantRating: action.restaurantRating
            }
        }
        case SELECT_RESTAURANT: {
            return {
                ...state,
                restaurantId: action.restaurantId
            };
        }
        default:
            return state;
    }
}

export default restaurantsReducer;