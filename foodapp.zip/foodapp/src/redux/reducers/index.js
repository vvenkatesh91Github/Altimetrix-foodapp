import { combineReducers } from "redux";
import foodsReducer from "./foods";
import restaurantsReducer from "./restaurants";

export default combineReducers(
{
    restaurants : restaurantsReducer,
    foods : foodsReducer
});
