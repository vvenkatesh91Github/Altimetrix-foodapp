import { LOAD_RESTAURANTS, LOAD_FOOD, SELECT_RESTAURANT, LOAD_ALL_RESTAURANTS, SEARCH_RESTAURANT } from "./actionTypes";

export const loadAllRestaurants = restaurants => ({type: LOAD_ALL_RESTAURANTS, restaurants });

export const loadRestaurants = restaurants => ({type: LOAD_RESTAURANTS, restaurants });

export const loadFoods = foods => ({type: LOAD_FOOD, foods });

export const selectResturant = restaurantId => ({type: SELECT_RESTAURANT, restaurantId });

export const searchRestaurant = (restaurantName, restaurantRating) => ({type: SEARCH_RESTAURANT, restaurantName, restaurantRating});